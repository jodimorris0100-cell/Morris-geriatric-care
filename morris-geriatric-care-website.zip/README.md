# Morris Geriatric Care & Senior Consulting

A responsive one-page website for a geriatric nursing and senior consulting business.

## Before launch
Replace the placeholder email and phone number in `index.html` with the business contact details.
Connect the contact form to an email/form service or website host.
Review all service wording so it accurately reflects the services and professional scope offered.
